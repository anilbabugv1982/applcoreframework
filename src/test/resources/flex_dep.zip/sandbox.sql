commit;
update FND_kF_FLEXFIELDS_B set deployment_status = 'DEPLOYED';
update FND_dF_FLEXFIELDS_B set deployment_status = 'DEPLOYED';
update fnd_df_flexfields_b set deployment_status='SANDBOXED' where descriptive_flexfield_code in ('INV_GRADES','PER_LOCATION_INFORMATION_EFF');
update fnd_kf_flexfields_b set deployment_status='SANDBOXED' where key_flexfield_code='COST';
commit;
exit;
