connect('faadmin','Fusionapps1','t3://slc17kxr.us.oracle.com:11401')
deployPatchedFlex()
exit()


