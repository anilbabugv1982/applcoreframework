connect('faadmin','Fusionapps1','t3://slc17kxr.us.oracle.com:11401')
deployFlex('INV_GRADES','DFF')
deployFlex('PER_LOCATION_INFORMATION_EFF','EFF')
deployFlex('COST','KFF')
exit()


