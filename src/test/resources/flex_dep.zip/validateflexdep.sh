#!/bin/bash

APPLTOP=/u01/APPLTOP/fusionapps/atgpf/lcm/ad/bin
WLST=/u01/APPLTOP/fusionapps/atgpf/common/bin/wlst.sh
EDIT_LOG=edit.log
ERROR_LOG=error.log
READY_LOG=ready.log
SANDBOX_LOG=sandbox.log
DEPLOY_LOG=deployed.log
PWD=${PWD}

rm ${APPLTOP}/*.log  >& /dev/null

echo "Starting deployFlex Validation ........" 

sh ${APPLTOP}/adsetenv.sh  >& /dev/null
source ${PWD}/APPSORA.env

sed -i "1s#.*#connect(\'faadmin\',\'Fusionapps1\',\'t3://`hostname`:11401\')#" deployflex.py

validatedeployment(){

DFF_CODE=`grep "Deployed Successfully"  $3 | grep "Descriptive" | cut -d " " -f2-4`
EFF_CODE=`grep "Deployed Successfully"  $3 | grep "Extensible" | cut -d " " -f2-4`
KFF_CODE=`grep "Deployed Successfully"  $3 | grep "Key" | cut -d " " -f2-4`

grep "^<FlexfieldDeploymentReport" $3 | grep "DFF code=\"INV_GRADES\" applicationId=\"401\" status=\"DEPLOYED\"" >& /dev/null

if [ $? == "0" ];then
      echo "${DFF_CODE} : deployFlex Scenario $1 - $2 : PASS"
else
      echo "${DFF_CODE} : deployFlex Scenario $1 - $2 : FAIL -> Log File $3"
fi

grep "^<FlexfieldDeploymentReport" $3 | grep "EFF code=\"PER_LOCATION_INFORMATION_EFF\" applicationId=\"800\" status=\"DEPLOYED\"" >& /dev/null

if [ $? == "0" ];then
      echo "${EFF_CODE} : deployFlex Scenario $1 - $2 : PASS"
else
      echo "${EFF_CODE} : deployFlex Scenario $1 - $2 : FAIL -> Log File $3"
fi

grep "^<FlexfieldDeploymentReport" $3 | grep "KFF code=\"COST\" applicationId=\"801\" status=\"DEPLOYED\"" >& /dev/null

if [ $? == "0" ];then
 	echo "${KFF_CODE} : deployFlex Scenario $1 - $2 : PASS"
else
	echo "${KFF_CODE} : deployFlex Scenario $1 - $2 : FAIl -> Log File $3"
fi

}

sqlplus $1 @edit.sql >& /dev/null
${WLST} deployflex.py > ${APPLTOP}/${EDIT_LOG} 2>&1
 
echo "######################### Validating EDIT-DEPLOYED scenarios ################################"
echo " "
validatedeployment EDITED DEPLOYED ${APPLTOP}/${EDIT_LOG}
echo " "
echo "##########################Validation EDIT-DEPLOYED completed ################################"
echo " "

sqlplus $1 @error.sql >& /dev/null
${WLST} deployflex.py > ${APPLTOP}/${ERROR_LOG} 2>&1 

echo "######################## Validating ERROR-DEPLOYED scenarios ################################"
echo " "
validatedeployment ERROR DEPLOYED ${APPLTOP}/${ERROR_LOG}
echo " "
echo "######################## Validation of ERROR-DEPLOYED completed #############################"
echo " "

sqlplus $1 @ready.sql >& /dev/null
${WLST} deployflex.py > ${APPLTOP}/${READY_LOG} 2>&1 

echo "######################## Validating READY-DEPLOYED scenarios ################################"
echo " "
validatedeployment READY DEPLOYED ${APPLTOP}/${READY_LOG}
echo " "
echo "######################## Validation of READY-DEPLOYED completed #############################"

sqlplus $1 @sandbox.sql >& /dev/null
${WLST} deployflex.py > ${APPLTOP}/${SANDBOX_LOG} 2>&1 

echo " "
echo "######################## Validating SANDBOXED-DEPLOYED scenario  ################################"
echo " "
validatedeployment SANDBOXED DEPLOYED ${APPLTOP}/${SANDBOX_LOG}
echo " "
echo "######################## Validation of SANBOXED-DEPLOYED completed #############################"
echo " "

sqlplus $1 @deployed.sql >& /dev/null
${WLST} deployflex.py > ${APPLTOP}/${DEPLOY_LOG} 2>&1 

echo "######################## Validating DEPLOYED-DEPLOYED scenario  ################################"
echo " "
validatedeployment DEPLOYED DEPLOYED ${APPLTOP}/${DEPLOY_LOG}
echo " "
echo "######################## Validation of DEPLOYED-DEPLOYED completed #############################"
echo " "
