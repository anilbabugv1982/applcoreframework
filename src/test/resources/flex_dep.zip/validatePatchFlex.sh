#!/bin/bash

APPLTOP=/u01/APPLTOP/fusionapps/atgpf/lcm/ad/bin
WLST=/u01/APPLTOP/fusionapps/atgpf/common/bin/wlst.sh
EDIT_LOG=patch_edit.log
ERROR_LOG=patch_error.log
READY_LOG=patch_ready.log
EDITREADY_LOG=patch_editready.log
SANDBOX_LOG=patch_sandbox.log
DEPLOY_LOG=patch_deployed.log
PWD=${PWD}

rm ${APPLTOP}/*.log >& /dev/null

sh ${APPLTOP}/adsetenv.sh >& /dev/null
source ${PWD}/APPSORA.env

sed -i "1s#.*#connect(\'faadmin\',\'Fusionapps1\',\'t3://`hostname`:11401\')#" deppatchflex.py

echo "Starting deployPatchedFlex Validation using deployPatchedFlex() ........."
echo " "

validatedeployment(){

DFF_CODE=`grep "Deployed Successfully"  $3 | grep "Descriptive" | cut -d " " -f2-4`
EFF_CODE=`grep "Deployed Successfully"  $3 | grep "Extensible" | cut -d " " -f2-4`
KFF_CODE=`grep "Deployed Successfully"  $3 | grep "Key" | cut -d " " -f2-4`

grep "^<FlexfieldDeploymentReport" $3 | grep 'DFF code="INV_GRADES" applicationId="401" status="DEPLOYED"' >& /dev/null

if [ $? == "0" ];then
	echo "${DFF_CODE} : deployPatchedFlex Scenario $1 - $2 : PASS"
else
	echo "${DFF_CODE} : deployPatchedFlex Scenario $1 - $2 : FAIL -> LogFile $3"
fi

grep "^<FlexfieldDeploymentReport" $3 | grep "EFF code=\"PER_LOCATION_INFORMATION_EFF\" applicationId=\"800\" status=\"DEPLOYED\"" >& /dev/null

if [ $? == "0" ];then
	echo "${EFF_CODE} : deployPatchedFlex Scenario $1 - $2 : PASS"
else
	echo "${EFF_CODE} : deployPatchedFlex Scenario $1 - $2 : FAIL -> LofFile  $3"
fi

grep "^<FlexfieldDeploymentReport" $3 | grep "KFF code=\"COST\" applicationId=\"801\" status=\"DEPLOYED\"" >& /dev/null

if [ $? == "0" ];then
	echo "${KFF_CODE} : deployPatchedFlex Scenario $1 - $2 : PASS"
else
	echo "${KFF_CODE} : deployPatchedFlex Scenario $1 - $2 : FAIL  -> LogFile $3"
fi

}


sqlplus $1 @error.sql >& /dev/null
${WLST} deppatchflex.py  > ${APPLTOP}/${ERROR_LOG} 2>&1
echo " "
echo "######################## Validating ERROR - ERROR scenarios ################################"
grep "No Flexfields changes found. Flexfield deployment status is up to date" ${APPLTOP}/${ERROR_LOG} >& /dev/null
if [ $? == "0" ];then
      echo "ALL deployPatchedFlex Status ERROR - ERROR scenario : PASS"
else
      echo "ALL deployPatchedFlex Status ERROR - ERROR scenario : FAIL -> LogFile ${APPLTOP}/${ERROR_LOG}"
fi

echo "######################## Validation of ERROR - ERROR Scenarios Completed ####################"
echo " "

sqlplus $1 @ready.sql >& /dev/null
${WLST} deppatchflex.py > ${APPLTOP}/${READY_LOG} 2>&1
echo " "
echo "######################## Validating READY - DEPLOYED scenarios ################################"
validatedeployment READY  DEPLOYED ${APPLTOP}/${READY_LOG}
echo "######################## Validation of READY - DEPLOYED completed #############################"
echo " "



sqlplus $1 @edit.sql >& /dev/null
${WLST} deppatchflex.py > ${APPLTOP}/${EDIT_LOG} 2>&1
echo " "
echo "######################### Validating EDITED - EDITED scenarios ################################"

grep "No Flexfields changes found. Flexfield deployment status is up to date" ${APPLTOP}/${EDIT_LOG} >& /dev/null
if [ $? == "0" ];then
      echo "ALL deployPatchedFlex Status EDITED - EDITED scenario : PASS"
else
      echo "ALL deployPatchedFlex Status EDITED - EDITED scenario : FAIL -> LogFile ${APPLTOP}/${EDIT_LOG}"
fi

echo "##########################Validation of EDITED - EDITED completed ##############################"
echo " "


sqlplus $1 @sandbox.sql >& /dev/null
${WLST} deppatchflex.py > ${APPLTOP}/${SANDBOX_LOG} 2>&1
echo " "
echo "######################### Validating SANDBOXED  - SANDBOXED scenarios ################################"

grep "No Flexfields changes found. Flexfield deployment status is up to date" ${APPLTOP}/${SANDBOX_LOG} >& /dev/null
if [ $? == "0" ];then
      echo "ALL deployPatchedFlex Status SANDBOXED  - SANDBOXED scenario : PASS"
else
      echo "ALL deployPatchedFlex Status SANDBOXED  - SANDBOXED scenario : FAIL -> LogFile ${APPLTOP}/${SANDBOX_LOG}"
fi

echo "##########################Validation of SANDBOXED  - SANDBOXED completed ##############################"
echo " "


sqlplus $1 @deployed.sql >& /dev/null
${WLST} deppatchflex.py > ${APPLTOP}/${DEPLOY_LOG} 2>&1
echo " "
echo "######################### Validating DEPLOYED - DEPLOYED scenarios ################################"

grep "No Flexfields changes found. Flexfield deployment status is up to date" ${APPLTOP}/${DEPLOY_LOG} >& /dev/null
if [ $? == "0" ];then
      echo "ALL deployPatchedFlex Status DEPLOYED - DEPLOYED scenario : PASS"
else
      echo "ALL deployPatchedFlex Status DEPLOYED - DEPLOYED scenario : FAIL -> LogFile ${APPLTOP}/${DEPLOY_LOG}"
fi

echo "##########################Validation of DEPLOYED - DEPLOYED completed ##############################"
echo " "


sqlplus $1 @edit_ready.sql >& /dev/null
${WLST} deppatchflex.py > ${APPLTOP}/${EDITREADY_LOG} 2>&1
echo " "
echo "######################## Validating EDITED_READY - DEPLOYED scenarios ################################"
validatedeployment EDITED_READY  DEPLOYED ${APPLTOP}/${EDITREADY_LOG}
echo "######################## Validation of EDITED_READY - DEPLOYED completed #############################"
echo " "
